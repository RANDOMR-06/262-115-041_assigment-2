#include<stdio.h>
int main () {
int n , i,Sum=0;
scanf( "%d",&n);
for( i= 1; i<= n;i++){
    Sum=Sum+i;
}
printf("Sum=%d",Sum);

return 0;
}
